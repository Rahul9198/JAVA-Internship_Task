public class Array {
    public static void main(String[] args) {

        // int[][] a = new int[3][3];
        
        int[][] a = {{1,2,3}, {4,5,6}};

        for(int i = 0; i<=a.length; i++){
            // System.out.println(a[i]);
            for(int j = 0; i<3; j++){
                System.out.println();
            }
        }
        //  int[] a = {4, 5, 6, 7, 'n'};
        //  System.out.println(a[4]); 
        //ArrayIndexOutOfBoundationException error
        // System.out.println(a.length);

        // String[] a = {"Pooja", "Suraj", "Rahul", "Vivek"};
        // System.out.println(a);
        // System.out.println(a[1]);
        // System.out.println(a.length);


        //Declaration/Initiation of Array
        // int[] a = new int[15];
        // // System.out.println(a.length);
        // a[0] = 8;
        // a[3] = 5;
        // a[6] = 9;
        // a[9] = 1887;
        // a[9] = 32;

        // int x = a.length;

        // for (int counter = 0; counter<=x; counter++) {
        //     System.out.println(a[counter]);
        // }
    //     System.out.println(a[0]);
    //     System.out.println(a[1]);
    //     System.out.println(a[2]);
    //     System.out.println(a[3]);
    //     System.out.println(a[4]);
    }                
}
