//23/05/2024

public class Second {
    public static void main(String[] args) {

    String a = "My name";
    String b = " is Rahul";
    String c = " Verma";
    String d = " from Bangalore.";
    String e = "Rahul Kumar Verma";
    System.out.println(e.replace("u", "U"));
    // System.out.println(e.replaceFirst("l", "L"));
    // System.out.println(e.replaceAll("a", "A"));

    // System.out.println(String.join(" Kumar ", "Rahul", "Verma"));

    System.out.println(a + " " + b +" " + c + " " + d);
    // System.out.println(a.concat(b));
    // String x = a.concat(b);
    // System.out.println(x);
    // String y = x.concat(c);
    // System.out.println(y);
    // String z = y.concat(d);
    // System.out.println(z);
    





        // double a = 4.786578976545678;
        // double b = 4.78765787832864827;

        // System.out.println("Double accepts:" + a);
        // System.out.println("Float accepts: " + b);

        // String a =  "   Hello World";
        // System.out.println(a);
        // System.out.println(a.trim());//to remove white space
        // System.out.println(a.length());
        // System.out.println(a.toUpperCase());
        // System.out.println(a.toLowerCase());
        // System.out.println(a.indexOf('z')); //-1 for missing value in available string
        // System.out.println(a.indexOf('o'));
        // System.out.println(a.indexOf('O'));
        // System.out.println(a.contains("z")); //false
        // System.out.println(a.contains("W"));
        // System.out.println(a.charAt(0));
        // System.out.println(a.startsWith(" "));
        // System.out.println(a.endsWith("rld"));
        // System.out.println(a.charAt(7));

        //Boolean x = true;
        // System.out.println(x);

    }
    
}
