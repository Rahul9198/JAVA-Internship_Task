/*print even number in Given Range */

import java.util.Scanner;

public class even {
    public static void main(String[] args) {
        int n;
        System.out.println("Enter Number of term::");
        Scanner sc = new Scanner(System.in);
        n = sc.nextInt();
        for (int i = 0; i <= n; i=i+2) {
            System.out.println(i);
        
    }
    
}
}
