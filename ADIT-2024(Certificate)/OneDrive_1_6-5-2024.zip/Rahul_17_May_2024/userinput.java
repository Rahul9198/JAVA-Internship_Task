import java.util.Scanner;

class userinput
{
    public static void main(String[] args) {
        int a;
        Scanner obj=new Scanner(System.in);
        System.out.println("Enter any number::");
        a=obj.nextInt();
        System.out.println(a);
        
    }
}