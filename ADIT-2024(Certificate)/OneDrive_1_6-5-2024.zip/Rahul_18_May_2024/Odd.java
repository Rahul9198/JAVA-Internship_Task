import java.util.Scanner;

public class Odd {
    public static void main(String[] args) {
        int n;
        System.out.println("Enter no of Range::");
        Scanner sc = new Scanner(System.in);
        n = sc.nextInt();
        for (int i = 1; i <= n; i=i+2) {
            System.out.println(i);


    }
}
}