public class Static_member1 {
    int x;//instance variable
    static int y;//static member variable
    public void fun1(){}//instance member function
    public static void fun2(){}//static  
    
}
