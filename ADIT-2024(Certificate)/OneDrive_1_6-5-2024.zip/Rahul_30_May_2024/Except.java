//COMPILE TIME ERROR EXAMPLE

import java.lang.reflect.Array;
import java.math.BigInteger;
import java.time.LocalDate;
import java.util.List;

public class Except {
    public static void main(String[] args) {
        // print("hello"); //error
        // System.out.println("hello");
        // System.out.printLn("hello"); //error

        // int a = "bul"; //error incompatible types
        // String a = "Rahul";
        // System.out.println(A); //case mismatch error
        // System.out.println(a);
        // int a = 45;
        // int b = 0;
        // int c = a/b;//arithmation exception

        // System.out.println(c);
        // String a = null;

        // System.out.println(a.length());//NUllpoint Exception
        // LocalDate a = new Date.now();//date 
        // int [] a = {5,6,7,8};
        // System.out.println(a[5]);//ArrayIndexoutofBounds Exception

        // Number[] bigint = new BigInteger[5];
        // bigint[0] = Double.valueOf(1222.3366978);//Arraystore Exception
        // int [] a = {3,4,5,6};
        // List<Integer>b=Array.asList(a);
        // b.add(new Integer(8));//unsupported operators



    }
}