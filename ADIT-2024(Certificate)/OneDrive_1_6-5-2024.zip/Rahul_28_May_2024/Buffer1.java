public class Buffer1 {
    public static void main(String[] args) {
        StringBuffer sb = new StringBuffer("INDIA");
        sb.append("is always great");
        System.out.println(sb);
        sb.insert(0, 0);
        System.out.println(sb);
        // System.out.println(sb.capacity());
        // sb.append(" is big Country");
        // System.out.println(sb);
        // sb.append("Live long");
        // sb.deleteCharAt(3);
        // System.out.println(sb);



    }
    
}
