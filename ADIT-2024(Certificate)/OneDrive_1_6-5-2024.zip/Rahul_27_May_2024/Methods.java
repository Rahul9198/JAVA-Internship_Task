public class Methods {

    static String hello(){
        // System.out.println("Hello World!!!");
        return ("hello");
        // return (109);
        String a = "Nashit";
        System.out.println(a);        
        int[] z = {1,2,3, 4, 5, 6, 7, 8, 9, 10};
    } 


    public static String main(String[] args) {
        // String a = "Nashit";
        // int b = 5;
        // int x=8;
        return ("hello");
        
    //    String a = hello();
    //    System.out.println(a);
    // //    return("hello");
    //    System.out.println("hello");
        // int a = 10;
        // int b = 20;
        // int c = a+b;
        // System.out.println(c);
    }
}
