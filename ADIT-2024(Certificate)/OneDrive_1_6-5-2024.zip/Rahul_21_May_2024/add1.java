//java program to add two numbers without user input

public class add1 {
    public static void main(String [] args){
        int a,b,sum;
        a=20;
        b=10;
        sum=a+b;

        System.out.println(sum);
    }
}
